README Trains

INSTRUCTIONS
1. The Main File that must be executed first is Main.java.

2. The vertices must be created. There is a file called vertex.txt that must be loaded by choosing option 1 from the menu. After loading, a specific method will create the vertices.

3. With the vertices created, we can create the graph by choosing option 2 from the menu. As with vertices, it is necessary to load a file (graph.txt) containing the structure of the graph. After loading the graph will be created by a specific method.

4. To run a method with route tests, just choose function 3 from the menu.

5. To finish the execution, just choose option 4 from the menu or click on any other key.



IMPORTANT!
The files for testing are located in the project's FILES folder.